﻿using System;
using System.Linq;

namespace _08.SequenceOfMaxSum
{
    class SequenceOfMaxSum
    {
        static void Main(string[] args)
        {
            // To DO !!! 
        }
    }
}
