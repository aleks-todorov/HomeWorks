﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.PrintingCurrentDay
{
    class PrintingCurrentDay
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Today.DayOfWeek);
        }
    }
}
